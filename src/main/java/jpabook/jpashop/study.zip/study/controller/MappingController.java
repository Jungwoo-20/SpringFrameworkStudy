package jpabook.jpashop.study.controller;

public class MappingController {

}
