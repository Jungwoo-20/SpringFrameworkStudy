package jpabook.jpashop.study.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/member")
public class MemberController {
    private MemberRepository memberRepository = new MemberRepository();

    @RequestMapping("/new")
    public String newMember() {
        //return new ModelAndView("new-form");
        return "new-form"; //뷰의 논리적인 이름만 적어도 수행된
    }

    //@RequestMapping(value = "/add", method = RequestMethod.POST) // 아래랑 같은 방법임
    @PostMapping("/add")
    public String addMember(@ModelAttribute Member member, Model model) {
        memberRepository.save(member);
        model.addAttribute("member", member);
        return "add-result";
    }

    @RequestMapping("/all")
    public ModelAndView addMember() {
        List<Member> members = memberRepository.findAll();
        ModelAndView mv = new ModelAndView("member-list");
        mv.addObject("members", members);
        return mv;
    }

    @RequestMapping("/hello")
    public String hello() {
        return "<html><body><h1>Hello, ResponseBody!</h1></body></html>";
    }

    @GetMapping({"/api/{id}/{age}", "/api/{id}/"})
    public String getMemberById(@PathVariable("id") Long id, @PathVariable Optional<Integer> age) {
        //return "name : " + memberRepository.findById(memberId).getName() + ", age : " + age;
        return Optional.ofNullable(age).map(x -> "id : " + id + ", age : " + x).orElseGet(() -> "id : " + id);
    }

    @PostMapping("/requestBody")
    public String requestBodyHandler(@RequestBody Member member) {
        log.info("member = {}", member);
        return "ok";
    }

    @PostMapping("/requestBody2")
    public HttpEntity<String> requestBodyHandler2(HttpEntity<String> httpEntity) {
        String body = httpEntity.getBody();
        log.info("httpBody = {}", body);
        return new HttpEntity<>("ok");
    }
}
